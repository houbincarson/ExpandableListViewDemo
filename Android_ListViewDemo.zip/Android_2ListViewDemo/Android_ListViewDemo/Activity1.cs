﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace Android_ListViewDemo
{
    [Activity(Label = "Android_ListViewDemo")]
    public class Activity1 : Activity
    {
        private static LayoutInflater mInflater;
        private static MyListView mListView;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle); 
            SetContentView(Resource.Layout.Main);

            mListView = this.FindViewById(Android.Resource.Id.List)as MyListView; 
            //设置列头
            mListView.mListHead = this.FindViewById<LinearLayout>(Resource.Id.head);
            //设置数据
            mListView.Adapter = new DataAdapter(); 
            mInflater = GetSystemService(LayoutInflaterService) as LayoutInflater;
            mListView.ItemClick += mListView_ItemClick;
            Button btn = this.FindViewById(Resource.Id.button1) as Button;
            btn.Click += btn_Click;
        }

        void btn_Click(object sender, EventArgs e)
        {
          Intent intent = new Intent (this,typeof(Activity2));
            StartActivity(intent);
        }

        void mListView_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            Toast.MakeText(this,e.Position.ToString(),ToastLength.Short).Show();
        }
        class DataAdapter : BaseAdapter {

            public override int Count
            {
                get { return 50; }//固定显示50行数据
            }

            public override Java.Lang.Object GetItem(int position)
            {
                return null;
            }

            public override long GetItemId(int position)
            {
               return 0;
            }

            public override View GetView(int position, View convertView, ViewGroup parent)
            {
                if (convertView == null)
                {
                    convertView = mInflater.Inflate(Resource.Layout.item, null);
                }

                for (int i = 0; i < 8; i++)
                {
                    ((TextView)convertView.FindViewById(Resource.Id.item2 + i)).Text = "数据" + position + "行" + (i + 2) + "列";
                }
                //校正（处理同时上下和左右滚动出现错位情况）
                View child = ((ViewGroup)convertView).GetChildAt(1);
                int head = mListView.getHeadScrollX();
                if (child.ScrollX != head)
                {
                    child.ScrollTo(mListView.getHeadScrollX(), 0);
                }
                return convertView;
            }
        }
    }
}

