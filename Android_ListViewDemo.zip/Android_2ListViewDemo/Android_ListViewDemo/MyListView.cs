﻿using Android.Content;
using Android.Util;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Text;
using Android.App; 

namespace Android_ListViewDemo
{ 
    class MyListView : ListView,Android.Views.GestureDetector.IOnGestureListener
    {
        /** 手势 */
        private GestureDetector mGesture;
        /** 列头 */ 
        public LinearLayout mListHead; 
        /** 偏移坐标 */ 
        private int mOffset = 0;
        /** 屏幕宽度 */  
        private int screenWidth; 

        #region 构造函数 
        public MyListView(Context context)
            : base(context)
        {
            mGesture = new GestureDetector(context, this);
        }
        public MyListView(Context context, IAttributeSet attrs)
            : base(context, attrs)
        {
            mGesture = new GestureDetector(context, this);
        }
        public MyListView(Context context, IAttributeSet attrs, int defStyle)
            : base(context, attrs, defStyle)
        {
            mGesture = new GestureDetector(context, this);
        } 
        #endregion
         /** 分发触摸事件 */
        public override bool DispatchTouchEvent(MotionEvent e)
        {
            //this.DispatchTouchEvent(e);
            return mGesture.OnTouchEvent(e);
        }
         
        //down事件
        public bool OnDown(MotionEvent e)
        {
            return true;
        }
        public bool OnFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY)
        {
            //滑动手势事件；Touch了滑动一点距离后，在ACTION_UP时才会触发参数：e1 第1个ACTION_DOWN MotionEvent 并且只有一个；e2 最后一个ACTION_MOVE MotionEvent ；velocityX X轴上的移动速度，像素/秒 ；velocityY Y轴上的移动速度，像素/秒.触发条件：X轴的坐标位移大于FLING_MIN_DISTANCE，且移动速度大于FLING_MIN_VELOCITY个像素/秒
            return false;
        }

        public bool OnSingleTapUp(MotionEvent e)
        {
            /*一次点击up事件；在touch down后又没有滑动（onScroll），又没有长按（onLongPress），然后Touchup时触发。
             点击一下非常快的（不滑动）Touchup：onDown->onSingleTapUp->onSingleTapConfirmed 
             点击一下稍微慢点的（不滑动）Touchup：onDown->onShowPress->onSingleTapUp->onSingleTapConfirmed*/
            return true;
        }


        public void OnLongPress(MotionEvent e)
        {
            //长按事件；Touch了不移动一直Touch down时触发 
        }
        public void OnShowPress(MotionEvent e)
        {
            //down事件发生而move或则up还没发生前触发该事件；Touch了还没有滑动时触发（与onDown，onLongPress）比较onDown只要Touch down一定立刻触发。而Touchdown后过一会没有滑动先触发onShowPress再是onLongPress。所以Touchdown后一直不滑动 按照onDown->onShowPress->onLongPress这个顺序触发。
        }
        /** 滚动 */
        public bool OnScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY)
        {
            //在屏幕上拖动事件。无论是用手拖动view，或者是以抛的动作滚动，都会多次触发,这个方法在ACTION_MOVE动作发生时就会触发
            //抛：手指触动屏幕后，稍微滑动后立即松开onDown-----》onScroll----》onScroll----》onScroll----》………----->onFling
            //拖动onDown------》onScroll----》onScroll------》onFiling

            lock(this){
                int moveX = (int)distanceX;

                int curX = mListHead.ScrollX;
                int scrollWidth = Width;
                int dx = moveX;
                //控制越界问题
                if (curX + moveX < 0)
                    dx = 0;
                
                if (curX + moveX + getScreenWidth() > scrollWidth)
                    dx = scrollWidth - getScreenWidth() - curX;

                mOffset += dx;
                //根据手势滚动Item视图
                for (int i = 0, j = ChildCount; i < j; i++)
                {
                    View child = ((ViewGroup)GetChildAt(i)).GetChildAt(1);
                    if (child.ScrollX != mOffset)
                        child.ScrollTo(mOffset, 0);
                }
                mListHead.ScrollBy(dx, 0);
            }
            RequestLayout();
            return true;
        }

        private int getScreenWidth()
        {
            if (screenWidth == 0)
            { 
                //DisplayMetrics dm = new DisplayMetrics();// 获取分辨率宽度  
                screenWidth = this.Context.Resources.DisplayMetrics.WidthPixels;
                if ( GetChildAt(0) != null)
                {
                    screenWidth -= ((ViewGroup)GetChildAt(0)).GetChildAt(0).MeasuredWidth; 
                }
                else if (mListHead != null)
                {
                    //减去固定第一列
                    screenWidth -= mListHead.GetChildAt(0).MeasuredWidth;
                }
            }
            return screenWidth;
        }
        /** 获取列头偏移量 */
        public int getHeadScrollX()
        {
            return mListHead.ScrollX;
        }  
    }
}
